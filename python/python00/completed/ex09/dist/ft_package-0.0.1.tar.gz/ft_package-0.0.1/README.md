# Example Package

I have no idea what am i doing
Simple Package for 42 ex09 Python Module